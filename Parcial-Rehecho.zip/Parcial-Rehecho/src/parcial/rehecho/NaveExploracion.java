
package parcial.rehecho;

public class NaveExploracion extends NaveEspacial implements Explorable{
    private TipoMision mision;

    public NaveExploracion(TipoMision mision, String nombre, int capacidadTripulacion, int anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.mision = mision;
    }

    @Override
    public void explorar() {
        System.out.println("Iniciando exploracion de " + getNombre());
    }
    
    
    @Override
    public String toString() {
        return "NaveDeExploracion " + super.toString()  + ", mision= " + mision + '}';
    }
    
}

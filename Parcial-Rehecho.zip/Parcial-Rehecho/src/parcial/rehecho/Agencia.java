
package parcial.rehecho;


import java.util.ArrayList;
import java.util.List;

public class Agencia {
    private List<NaveEspacial> navesEspaciales;

    public Agencia() {
        this.navesEspaciales = new ArrayList<>();
    }
    
    public void agregarNave(NaveEspacial nave) {
        if(nave == null){
            throw new NullPointerException("Lo que quieres agregar es null");
        }
        if(navesEspaciales.contains(nave)){
            throw new NaveRepetidaException();
        }
        navesEspaciales.add(nave);
    }
    
    public void mostrarNaves(){
        // recorro la lista de naves e imprimo sus datos a traves del metodo toString correspondiente de cada clase
        for(NaveEspacial nave : navesEspaciales){
            System.out.println(nave);
        }
    }
    
    public void iniciarExploracion(){
        for(NaveEspacial nave : navesEspaciales){
            if(nave instanceof Explorable explorador){
                explorador.explorar();
            }
            else{
                System.out.println(nave.getNombre() + " no es un explorador");
            }
        }
    }
    
}

package parcial.rehecho;

public interface Explorable {
    void explorar();
}


package parcial.rehecho;

public class CruceroEstelar extends NaveEspacial{
    private int cantidadPasajeros ;

    public CruceroEstelar(int cantidadPasajeros, String nombre, int capacidadTripulacion, int anioLanzamiento) {
        super(nombre, capacidadTripulacion, anioLanzamiento);
        this.cantidadPasajeros = cantidadPasajeros;
    }

    @Override
    public String toString() {
        return "CruceroEstelar{ " + super.toString() + "cantidadPasajeros= " + cantidadPasajeros + " }";
    }    

}

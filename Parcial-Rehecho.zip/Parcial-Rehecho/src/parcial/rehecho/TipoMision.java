
package parcial.rehecho;

public enum TipoMision {
    CARTOGRAFIA, INVESTIGACION, CONTACTO
}

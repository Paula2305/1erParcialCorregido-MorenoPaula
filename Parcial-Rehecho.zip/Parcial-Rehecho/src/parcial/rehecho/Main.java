
package parcial.rehecho;

public class Main {

   
    public static void main(String[] args) {
        Agencia agenciaEspacial = new Agencia();
        
        CruceroEstelar crucero = new CruceroEstelar(100,"Titanic",20,2003);
        Carguero carguero = new Carguero("Galactica",10,2000,200);
        NaveExploracion naveExploracion = new NaveExploracion(TipoMision.CARTOGRAFIA,"Exploradora3000",20,1980);
        
        try{
            agenciaEspacial.agregarNave(crucero);
            agenciaEspacial.agregarNave(carguero);
            agenciaEspacial.agregarNave(naveExploracion);
        }catch(NaveRepetidaException ex){
            System.out.println(ex);
        }
        
        agenciaEspacial.mostrarNaves();
        agenciaEspacial.iniciarExploracion();
    }
    
}
